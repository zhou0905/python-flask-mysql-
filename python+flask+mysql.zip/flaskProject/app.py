from flask import Flask, jsonify, request, render_template, redirect
from flask_sqlalchemy import SQLAlchemy
import pymysql
import json
app = Flask(__name__)

mysql_params = {
    'host': 'localhost',
    'user': 'root',  # 数据库用户名
    'passwd': 'root',  # 用户密码
    'db': 'hj',  # 数据库的名字
    'port': 3306,  # 端口号
    'charset': 'utf8'  # 编码方式
}
class Config():
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@localhost:3306/hj?charset=utf8mb4'
    SQLAlCHEMY_TRACK_MODIFICATIONS = True

app.config.from_object(Config)
db = SQLAlchemy(app)

class S_user(db.Model):
    __tablename__ = 's_user'
    name = db.Column(db.String(45), primary_key=True, nullable=False)
    pwd = db.Column(db.String(45))


class Hukou(db.Model):
    __tablename__ = 'hukouben'
    huhao = db.Column(db.Integer, primary_key=True, nullable=False)
    huzhu_name = db.Column(db.String(45), nullable=False)

class Member(db.Model):
    __tablename__ = 'member'
    id = db.Column(db.Integer, primary_key=True, nullable=False, auto_increment=True)
    huzhu_name = db.Column(db.String(10))
    sex = db.Column(db.String(5), nullable=False)
    birth_date = db.Column(db.String(20), nullable=False)
    sfz = db.Column(db.Integer, nullable=False)
    name = db.Column(db.String(45), nullable=False)
    qianrudi = db.Column(db.String(45), nullable=False)
    when_qianru = db.Column(db.String(45))
    died = db.Column(db.String(45))

class Sfz(db.Model):
    __tablename__ = 'sfz'
    sfz_name = db.Column(db.String(20), primary_key=True, nullable=False)
    sex = db.Column(db.String(10))
    sfz_date = db.Column(db.String(20))
    jg = db.Column(db.String(10))
    sfz_address = db.Column(db.String(50))
    sfz_id = db.Column(db.Integer)
    daoqifou = db.Column(db.String(50))


class huji(db.Model):
    __tablename__ = 'hujiinformation'
    id = db.Column(db.Integer, primary_key=True,auto_increment=True)
    huzhuname = db.Column(db.String(50), nullable=False)
    hunumber = db.Column(db.String(20))
    nation = db.Column(db.String(20))
    hediqianru = db.Column(db.String(50))
    qianrudate = db.Column(db.DateTime)
    qianchudate = db.Column(db.DateTime)
    qianruhedi = db.Column(db.String(50))
    address = db.Column(db.String(100))
    idcard = db.Column(db.String(18), nullable=False)


def create_mysql_conn():
    # pymysql连接rebecca数据库
    conn = pymysql.connect(host=mysql_params['host'],
                           port=mysql_params['port'],
                           user=mysql_params['user'],
                           passwd=mysql_params['passwd'],
                           db=mysql_params['db'],
                           charset=mysql_params['charset'])

    return conn

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    username = request.form.get('username')
    password = request.form.get('password')
    conn = create_mysql_conn()
    cursor = conn.cursor()
    query_sql = "select * from s_user where Name='" + username + "' and pwd='" + password + "';"
    n = cursor.execute(query_sql)
    if n:
        return render_template('index.html',name=username)
    return render_template('login.html')

@app.route('/in_info', methods=['POST','GET'])
def in_info():
    conn = create_mysql_conn()
    cursor = conn.cursor()
    sql = "select * from hukouben;"
    cursor.execute(sql)
    data = cursor.fetchall()
    return render_template('info.html', data=data)

@app.route('/InfoByName/<index>', methods=['POST','GET'])
def search_info_byname(index):
    conn = create_mysql_conn()
    cursor = conn.cursor()
    sql = "select huzhu_name from hukouben where huhao='"+ index+"';"
    cursor.execute(sql)
    name = cursor.fetchall()
    sql = "select * from member where huzhu_name='" + name[0][0] + "';"
    cursor.execute(sql)
    data = cursor.fetchall()
    return render_template('ShowByNum.html', data=data)

@app.route('/change/<index>', methods=['POST', 'GET'])
def change(index):
    conn = create_mysql_conn()
    cursor = conn.cursor()
    sql = "select huzhu_name from hukouben where huhao='" + index + "';"
    cursor.execute(sql)
    name = cursor.fetchall()
    sql = "select * from member where huzhu_name='" + name[0][0] + "';"
    cursor.execute(sql)
    data = cursor.fetchall()
    return render_template('change.html', data=data)

@app.route('/change1/', methods=['POST', 'GET'])
def change1():
    huzhu = request.form.get('huzhu')
    sex = request.form.get('sex')
    birth_date = request.form.get('birth_date')
    sfz = request.form.get('sfz')
    name = request.form.get('name')
    qianrudi = request.form.get('qianrudi')
    member = Member(huzhu_name=huzhu,sex=sex,birth_date=birth_date,sfz=sfz,name=name,qianrudi=qianrudi,when_qianru='2023')
    db.session.add(member)
    db.session.commit()

    return render_template('index.html')

@app.route('/ling', methods=['POST', 'GET'])
def ling():
    sfz_name = request.form.get('sfz_name')
    sex = request.form.get('sex')
    jg = request.form.get('jg')
    sfz_address = request.form.get('sfz_address')
    sfz = Sfz(sfz_name=sfz_name,sex=sex,sfz_date='2023',sfz_address=sfz_address,jg=jg, sfz_id=1,daoqifou=None)
    db.session.add(sfz)
    db.session.commit()
    return render_template('index.html')

@app.route('/alter/<num>', methods=['POST','GET'])
def alter(num):
    Member.query.filter(Member.id == num).update({'huzhu_name':None})
    db.session.commit()
    return render_template('index.html')
@app.route('/alter2/<name>', methods=['POST','GET'])
def alter2(name):
    sname = request.form.get('name')
    password = request.form.get('password')
    S_user.query.filter(S_user.name == name).update({'name':sname, 'pwd':password})
    db.session.commit()
    return render_template('ssuser.html')
@app.route('/dele/<num>', methods=['POST', 'GET'])
def dele(num):
    Member.query.filter(Member.id == num).update({'died': 'yes'})
    db.session.commit()
    return render_template('index.html')
@app.route('/dele2/<num>', methods=['POST', 'GET'])
def dele2(num):
    S_user.query.filter(S_user.name == num).delete()
    db.session.commit()
    return render_template('ssuser.html')
@app.route('/index')
def ina():
    return render_template('index.html')

@app.route('/sfz_info', methods=['POST', 'GET'])
def mem_info():
    conn = create_mysql_conn()
    cursor = conn.cursor()
    sql = "select * from sfz;"
    cursor.execute(sql)
    data = cursor.fetchall()
    return render_template('sfz_info.html', data=data)

@app.route("/select/<name>/<password>")
def select(args):
    conn = create_mysql_conn()
    # 创建一个游标
    cursor = conn.cursor()
    query_sql = "select * from s_user;"
    n = cursor.execute(query_sql)
    return json.dumps(n)

@app.route('/ssuer_login', methods=['POST', 'GET'])
def ss_login():
    username = request.form.get('name')
    password = request.form.get('pwd')
    conn = create_mysql_conn()
    cursor = conn.cursor()
    print(username)
    print(password)
    query_sql = "select * from ss_user where Name='" + username + "' and passwd='" + password + "';"
    n = cursor.execute(query_sql)
    if n:
        return render_template('ssuser.html',name=username)
    return render_template('login.html')

@app.route('/ss_user', methods=['POST', 'GET'])
def show():
    conn = create_mysql_conn()
    cursor = conn.cursor()
    sql = "select * from s_user;"
    cursor.execute(sql)
    data = cursor.fetchall()
    return render_template('ss_user.html', data=data)

@app.route('/add', methods=['POST','GET'])
def add():
    name = request.form.get('name')
    password = request.form.get('password')
    sfz = S_user(name=name, pwd=password)
    db.session.add(sfz)
    db.session.commit()
    return render_template('/ssuser.html')

if __name__ == '__main__':
    app.run(debug=True)