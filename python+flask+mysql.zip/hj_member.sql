-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: hj
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `huzhu_name` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `sex` varchar(5) CHARACTER SET latin1 NOT NULL,
  `birth_date` varchar(20) CHARACTER SET latin1 NOT NULL,
  `sfz` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `qianrudi` varchar(45) NOT NULL,
  `when_qianru` varchar(45) NOT NULL,
  `died` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'zhou','m','2000',111,'lzq','上海','',NULL),(2,'zhou','f','2001',222,'sh','北京','',NULL),(3,'swj','m','2002',333,'ln','江苏','',NULL),(4,'swj','f','2003',444,'lsp','浙江','',NULL),(5,'aaa','m','2004',555,'lll','安徽','',NULL),(6,'aaa','f','2005',666,'ccc','福建','',NULL),(7,'bbb','m','2006',777,'ddd','新疆','',NULL),(8,'bbb','f','2007',888,'ggg','沈阳','',NULL),(9,'zhou','f','2020',11111,'lzq2','shanghai','2023','yes'),(25,NULL,'f','2023',22222,'lzqaaa','上海','2023',NULL),(26,'zhou','m','2023',1111,'hcm','上海','2023',NULL),(27,'zhou','f','2023',22222,'lzqaaaaaaaa','上海','2023',NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-26 19:05:09
